#include <STC15F2K60S2.H>	//单片机头文件

void Seg_Disp(unsigned char wela,dula,point);
