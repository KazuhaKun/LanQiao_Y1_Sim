#include <STC15F2K60S2.H>	//单片机头文件

void Led_Disp(unsigned char addr,enable);