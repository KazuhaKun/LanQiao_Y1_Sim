#ifndef __ONEWIRE_H__
#define __ONEWIRE_H__

#include <STC15F2K60S2.H>

float rd_temperature();

#endif